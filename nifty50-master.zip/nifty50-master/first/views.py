from django.shortcuts import render


def record_sheet(request):
	